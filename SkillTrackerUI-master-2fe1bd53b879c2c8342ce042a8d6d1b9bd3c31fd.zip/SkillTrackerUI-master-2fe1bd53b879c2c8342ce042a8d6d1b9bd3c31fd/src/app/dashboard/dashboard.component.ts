import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { Employee } from '../models/Employee';
import { ChartData } from '../models/ChartData';

import { ActivatedRoute, Router } from '@angular/router'; 
import { CommsService } from '../services/comm.service';
import { AssociateService } from '../services/associate.service';
import { AssociateModel } from '../models/AssociateModel';
import { DomSanitizer } from '@angular/platform-browser';
import { Message, ConfirmationService } from 'primeng/api';
import { SkillService } from '../services/skill.service';
import { DashboardDataModel } from '../models/DashboardDataModel';
import { ChartSkills } from '../models/ChartSkills';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  @ViewChild('mainScreen') elementView: ElementRef;
  
  associateList: AssociateModel[];
  associateImg: any;
  widthExp = 500;
  color = 'red';
  chart: ChartData[] = [];
  message: Message[] = [];
  dashData: DashboardDataModel = null;
  skillDashData: ChartSkills[] = [];

  constructor(
    private elementRef: ElementRef,
    private route: ActivatedRoute,
    private router: Router,
    private comm: CommsService,
    private associateService: AssociateService,
    private _sanitizer: DomSanitizer,
    private confirmationService: ConfirmationService,
    private skillService: SkillService
  ) {
    this.getDashboardData();
    this.tableInit();
  }

  ngOnInit() {

    // this.cal();
  }

  tableInit() {
    this.associateService.getAssociateData().subscribe(data => {
      this.associateList = data;
      this.associateList.forEach((associate) => {
        var imgString = associate.Picture;
        associate.Picture =this._sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'+ imgString);                      
      });
    });
  }

  cal() {
    this.chart = [];
    const width = 1000;
    const skills = 5;
    const colors = ['blue', 'black', 'orange', 'red', 'pink'];
    const names = [ 'angular', 'react', '.net web api', 'EF', 'Mongoose' ];
    const employees = 20;
    const noofemployeesbyskill = [ 2, 2 , 10, 5, 1];
    noofemployeesbyskill.forEach((val, i) => {
      const vala = ((val)/employees)*100;
      this.chart.push({ widthExp: vala, color: colors[i], skillName: names[i]})
    });
  }

  onEditClick(employeeObj) {
    this.comm.storage = employeeObj;
    this.router.navigate(['/editemployee']);    
  } 

  onViewClick(employeeObj) {
    this.comm.viewStorage = employeeObj;
    this.router.navigate(['/editemployee']);  
  }

  deleteSkill(employeeObj) {
    this.confirmationService.confirm({
      message: 'Do you want to delete ' + employeeObj.Name + ' ?',
      header: 'Delete',
      key: 'del',
      icon: 'fa fa-trash',
      accept: () => {
        this.associateService.deleteAssociate(employeeObj).subscribe(data => {
          if (data == 'Success') {
            this.showMessage(true, "Skill Updated!");
          } else {
            this.showMessage(false, "Error");
          }
        });
      },
      reject: () => {

      }
    });
  }

  showMessage(status: boolean, message: string) {
    this.message = [];
    if (status === true) {
        this.message.push({ severity: 'success', summary: "Success", detail: message });
    }
    else {
        this.message.push({ severity: 'error', summary: "Error", detail: message });
    }
  }

  getDashboardData() {
    this.skillService.getDashboardData().subscribe(data => {
      this.dashData = data;
      this.skillDashData = this.dashData.Skill;
    });
  }
}
