import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AddskillComponent } from './addskill/addskill.component';
import { EmployeeComponent } from './employee/employee.component';



const appRoutes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: DashboardComponent },
  { path: 'addskill', component: AddskillComponent },
  { path: 'addemployee', component: EmployeeComponent },
  { path: 'editemployee', component: EmployeeComponent, data: {} }
];

@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule {}