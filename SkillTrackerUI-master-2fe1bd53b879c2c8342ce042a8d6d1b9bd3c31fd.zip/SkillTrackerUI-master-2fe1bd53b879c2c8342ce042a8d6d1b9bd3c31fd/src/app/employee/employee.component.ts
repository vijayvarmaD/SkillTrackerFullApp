import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { CommsService } from '../services/comm.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FormArray } from '@angular/forms/src/model';
import { SkillService } from '../services/skill.service';
import { Skill } from '../models/Skill';
import { AssociateService } from '../services/associate.service';
import { ImageModel } from '../models/ImageModel';
import { Observable } from 'rxjs/Observable';
import { Employee } from '../models/Employee';
import { AssociateModel } from '../models/AssociateModel';
import { Message, ConfirmationService } from 'primeng/api';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit, OnDestroy {
  @ViewChild('imgFileInput')
  myimgFileInputVariable: any;
  val: number = 23;
  numbers: number[] = [];
  mode: string = 'add';
  public addAssociateForm: FormGroup;
  skillsList: Skill[] = null;
  rawImage: ImageModel = null;
  encodedImage: ImageModel = null;
  associateFormObj: AssociateModel;
  imgPreview: any = null;
  disabledValue: any;
  message: Message[] = [];


  constructor(
    private comm: CommsService,
    private formBuilder: FormBuilder,
    private skillService: SkillService,
    private associateService: AssociateService,
    private router: Router
  ) {
    if (this.comm.storage !== null && this.comm.viewStorage == null) {    // Edit Mode
      this.mode = 'edit';
      this.onFormInit();
      this.onFormEditInit(this.comm.storage);
    } else if (this.comm.storage == null && this.comm.viewStorage !== null) {    // View Mode
      this.mode = 'view';
      this.onFormInit();
      this.onFormEditInit(this.comm.viewStorage);
      this.disabledValue = true;
    } else {     // Add Mode
      this.onFormInit();
    }

  }

  ngOnInit() {
  }

  ngOnDestroy() {
    this.comm.storage = null;
    this.comm.viewStorage = null;
  }

  // Initialization of Form - Add Mode
  onFormInit() {
    // initate form controls
    this.addAssociateForm = this.formBuilder.group({
      PictureControl: [null],
      StatusControl: [null, Validators.required],
      NameControl: [null, Validators.required],
      IDControl: [null, Validators.required],
      EmailControl: [null, Validators.required],
      MobileControl: [null, Validators.required],
      SkillsControl: this.formBuilder.array([
      ]),
      GenderControl: [null, Validators.required],
      LevelControl: [null, Validators.required],
      RemarkControl: [null],
      Strengths: [null],
      Weakness: [null],
    });

    // get list of skills available from api 
    this.getSkillsList();

  }

  getSkillsList() {
    this.skillService.getSkillsList().subscribe(data => {
      this.skillsList = data;
      this.patchSkillsList();
    });
  }

  addAssociateSubmit() {
    this.associateFormObj = {
      Picture: this.addAssociateForm.get('PictureControl').value,
      Status: this.addAssociateForm.get('StatusControl').value,
      Name: this.addAssociateForm.get('NameControl').value,
      ID: this.addAssociateForm.get('IDControl').value,
      Email: this.addAssociateForm.get('EmailControl').value,
      Mobile: this.addAssociateForm.get('MobileControl').value,
      Skills: this.addAssociateForm.get('SkillsControl').value,
      Gender: this.addAssociateForm.get('GenderControl').value,
      Level: Number.parseInt(this.addAssociateForm.get('LevelControl').value),
      Remark: this.addAssociateForm.get('RemarkControl').value,
      Strengths: this.addAssociateForm.get('Strengths').value,
      Weakness: this.addAssociateForm.get('Weakness').value
    }

    // Add Associate 
    if (this.mode == 'add') {   
      this.associateService.checkAssociateId(this.associateFormObj).subscribe(data => {
        if (data === 'OK') {
          this.associateService.addAssociateSubmit(this.associateFormObj).subscribe(data => {
            if (data == 'Success') {
              this.onReset();
              this.showMessage(true, 'Associate added!');
              this.getSkillsList();
            } else {
              this.showMessage(false, 'Associate Add Failed!');
            }
          });
        } else {
          this.showMessage(false, 'Associate ID already exists!');
        }
      }); 
      
    }
    // Update Associate 
    else if (this.mode == 'edit') {
      this.associateService.updateAssociateSubmit(this.associateFormObj).subscribe(data => {
        if (data == 'Success') {
          this.onReset();
          this.showMessage(true, 'Associate Updated!');
          this.router.navigate(['home']);
        } else {
          this.showMessage(false, 'Associate Update Failed!');
        }
      });
    }
    else {
      console.log(this.associateFormObj);
    }
    
  }

  patchSkillsList() {
    const formControl = <FormArray>this.addAssociateForm.controls.SkillsControl;

    if (this.mode == 'add') {
      // Add Employee
      const rating = 0;
      this.skillsList.forEach(x => {
        formControl.push(this.patchValues(x.Skill_Id, x.Skill_Name, rating))
      });
    }

  }

  // Skill Array Formbuilder
  patchValues(Skill_Id, Skill_Name, Skill_Rating) {
    return this.formBuilder.group({
      skillId: [Skill_Id],
      skillName: [Skill_Name],
      skillrating: [Skill_Rating]
    })
  }

  // image upload event listener
  changeListener($event): void {
    this.readThis($event.target);
    this.imgPreview = null;
  }

  // image reader
  readThis(inputValue: any): void {
    var file: File = inputValue.files[0];
    var myReader: FileReader = new FileReader();
    myReader.onloadend = () => {
      this.ImageUpload(myReader.result);
    }
    myReader.readAsDataURL(file);
  }

  // image uploader
  ImageUpload(base64Value) {
    var imgValue = base64Value.replace('-', '+')
      .replace('_', '/')
      .replace("data:image/jpeg;base64,", "")
      .replace("data:image/png;base64,", "");
    this.encodedImage = { FileToString: imgValue };
    this.addAssociateForm.patchValue({
      PictureControl: imgValue
    });
    // image upload service - not required
    // this.employeeService.uploadFile(this.encodedImage).subscribe(data => {
    //   console.log(data)
    // });
  }

  // Initialization of Form - Edit Mode
  onFormEditInit(associateObj) {
    this.addAssociateForm.patchValue({
      StatusControl: associateObj.Status.toLowerCase(),
      NameControl: associateObj.Name,
      IDControl: associateObj.ID,
      MobileControl: associateObj.Mobile,
      Strengths: associateObj.Strengths,
      EmailControl: associateObj.Email,
      GenderControl: associateObj.Gender,
      LevelControl: associateObj.Level.toString(),
      RemarkControl: associateObj.Remark,
      Weakness: associateObj.Weakness,
      PictureControl: associateObj.Picture
    });
    const formControl = <FormArray>this.addAssociateForm.controls.SkillsControl;
    // add skills to skill control
    associateObj.Skills.forEach(skill => {
        formControl.push(
          this.formBuilder.group({
            skillId: [skill.skillId],
            skillName: [skill.skillName],
            skillrating: [skill.skillrating],
            associateSkillId: [skill.associateSkillId]
          })
        );     
    });
    this.imgPreview = associateObj.Picture;
  }

  showMessage(status: boolean, message: string) {
    this.message = [];
    if (status === true) {
        this.message.push({ severity: 'success', summary: "Success", detail: message });
    }
    else {
        this.message.push({ severity: 'error', summary: "Error", detail: message });
    }
  }

  onReset() {
    this.onFormInit();    
  }

  editAssociateSubmit() {

  }
}
