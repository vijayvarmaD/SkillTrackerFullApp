export interface Skill {
    Skill_Id: number,
    Skill_Name: string
}