import { SafeResourceUrl } from "@angular/platform-browser";

// import { Skill } from "./SkillModel";

export class AssociateModel {
    Picture: SafeResourceUrl
    Status: number
    Name: string
    ID: number
    Email: string
    Mobile: number
    Skills: any[]
    Gender: string
    Level: number
    Remark: string
    Strengths: string
    Weakness: string

    constructor(
        picture: string,
        status: number,
        name: string,
        id: number,
        email: string,
        mobile: number,
        skills: any[],
        gender: string,
        remark: string,
        strengths: string,
        weakness: string
    ) {
        this.Picture = picture;
        this.Status = status;
        this.Name = name;
        this.ID = id;
        this.Email = email;
        this.Mobile = mobile;
        this.Skills = skills;
        this.Gender = gender;
        this.Remark = remark;
        this.Strengths = strengths;
        this.Weakness = weakness;
    }
}