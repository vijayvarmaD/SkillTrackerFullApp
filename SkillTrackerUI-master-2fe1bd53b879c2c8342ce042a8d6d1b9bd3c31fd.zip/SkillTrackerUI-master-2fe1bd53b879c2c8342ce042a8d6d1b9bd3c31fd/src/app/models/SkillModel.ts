

export class SkillModel {
    Skill_Id: number
    Skill_Name: string
    Skill_Rating: number
    AssociateSkills_Id: number

    constructor(
        id: number,
        name: string,
        rating: number,
        associateSkillsId: number
    ) {
        this.Skill_Id = id;
        this.Skill_Name = name;
        this.Skill_Rating = rating;
        this.AssociateSkills_Id = associateSkillsId
    }
}