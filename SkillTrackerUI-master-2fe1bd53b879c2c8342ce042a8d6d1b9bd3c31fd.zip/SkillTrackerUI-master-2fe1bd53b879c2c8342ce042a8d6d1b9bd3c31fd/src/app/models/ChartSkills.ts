export interface ChartSkills {
    Color: string,
    Name: string,
    Id: number,
    AssociateCount: number,
    Width: number
}
