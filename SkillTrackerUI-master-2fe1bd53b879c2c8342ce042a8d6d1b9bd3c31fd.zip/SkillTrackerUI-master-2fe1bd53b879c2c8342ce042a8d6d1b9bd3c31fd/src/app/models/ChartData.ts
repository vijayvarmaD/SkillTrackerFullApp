export interface ChartData {
    widthExp: number,
    color: string,
    skillName: string
}


