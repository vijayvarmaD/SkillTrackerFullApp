// import { Skill } from "./SkillModel";

export interface Employee {
    Employee_Picture: string,
    Employee_Status: number,
    Employee_Name: string,
    Employee_ID: number,
    Employee_Email: string,
    Employee_Mobile: number,
    Employee_Skills: any[],
    Employee_Gender: string,
    Employee_Remark: string,
    Employee_Strengths: string,
    Employee_Weakness: string
}