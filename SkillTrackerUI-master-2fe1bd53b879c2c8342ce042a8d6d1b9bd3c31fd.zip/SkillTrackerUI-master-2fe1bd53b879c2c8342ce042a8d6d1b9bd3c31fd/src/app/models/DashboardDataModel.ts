import { ChartSkills } from "./ChartSkills";

export interface DashboardDataModel {
    Skill: ChartSkills[],
    TotalAssociate: number,
    Level1: number,
    Level2: number,
    Level3: number,
    RatedAssociates: number
}
