import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';


import { AppComponent } from './app.component';

import { DataTableModule } from 'primeng/datatable';
import { ButtonModule } from 'primeng/button';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DialogModule } from 'primeng/dialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SliderModule } from 'primeng/slider';
import { GrowlModule } from 'primeng/growl';

import { ConfirmationService } from 'primeng/api';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AppRoutingModule } from './app-routing.module';
import { AddskillComponent } from './addskill/addskill.component';
import { EmployeeComponent } from './employee/employee.component';
import { CommsService } from './services/comm.service';
import { SkillService } from './services/skill.service';
import { AssociateService } from './services/associate.service';
import { Interceptor, fakeService } from './app.interceptor';


@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    AddskillComponent,
    EmployeeComponent
  ],
  imports: [
    BrowserModule,
    DataTableModule,
    ButtonModule,
    AppRoutingModule,
    ConfirmDialogModule,
    BrowserAnimationsModule,
    DialogModule,
    FormsModule,
    SliderModule,
    ReactiveFormsModule,
    HttpClientModule,
    GrowlModule
  ],
  providers: [
    ConfirmationService,
    CommsService,
    SkillService,
    AssociateService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
