import { Injectable } from '@angular/core';

@Injectable()
export class CommsService {

    public storage: any = null;

    public viewStorage: any = null;

    public constructor() { }

}