import { TestBed, inject } from '@angular/core/testing';

import { HttpClientModule } from '@angular/common/http';
import { CommsService } from './comm.service';

describe('Comms Service', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CommsService],
      imports:[HttpClientModule]

    });
  });

  it('Comms Service should be created', inject([CommsService], (service: CommsService) => {
    expect(service).toBeTruthy();
  }));
});
