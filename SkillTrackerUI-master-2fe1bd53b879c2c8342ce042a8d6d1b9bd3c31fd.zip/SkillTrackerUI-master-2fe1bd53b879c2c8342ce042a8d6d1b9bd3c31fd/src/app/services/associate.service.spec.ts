import { TestBed, inject } from '@angular/core/testing';


import { HttpClientModule } from '@angular/common/http';
import { AssociateService } from './associate.service';

describe('Associate Service', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AssociateService],
      imports:[HttpClientModule]

    });
  });

  it('Associate Service should be created', inject([AssociateService], (service: AssociateService) => {
    expect(service).toBeTruthy();
  }));
});
