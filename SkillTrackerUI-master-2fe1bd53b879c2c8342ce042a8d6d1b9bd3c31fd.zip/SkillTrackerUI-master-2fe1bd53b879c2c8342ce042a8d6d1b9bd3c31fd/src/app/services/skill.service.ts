import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';

import { RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../environments/environment';
import { Skill } from '../models/Skill';

@Injectable()
export class SkillService {
  constructor(private http: HttpClient) {}

  getSkillsList(): Observable<Skill[]> {   
    return this.http.get<Skill[]>(environment.apiUrl+"/api/skill/getall"); 
  }

  editSkill(skill: Skill): Observable<string> {
      console.log(skill);
      return this.http.post<string>(environment.apiUrl+"/api/skill/edit", skill);
  }

  addSkill(skill: Skill): Observable<string> {
      return this.http.post<string>(environment.apiUrl+"/api/skill/add", skill);
  }

  deleteSkill(skill: Skill): Observable<string> {
      return this.http.post<string>(environment.apiUrl+"/api/skill/delete", skill);
  }

  getDashboardData(): Observable<any> {
      return this.http.get<any>(environment.apiUrl+"/api/skill/dashboard");
  }

}
