import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpHeaders, HttpParams } from '@angular/common/http';

import { RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../environments/environment';
import { Skill } from '../models/Skill';
import { ImageModel } from '../models/ImageModel';
import { AssociateModel } from '../models/AssociateModel';

@Injectable()
export class AssociateService {
  constructor(private http: HttpClient) { }

  uploadFile(image: ImageModel): Observable<any> {
    return this.http.post<any>(environment.apiUrl + "/api/associate/imageupload", image);
  }

  // Add Associate form submit
  addAssociateSubmit(associateFormObj: AssociateModel): Observable<any> {
    console.log(associateFormObj);
    return this.http.post<any>(environment.apiUrl + "/api/associate/add", associateFormObj);
  }

  getAssociateData(): Observable<AssociateModel[]> {
    return this.http.get<AssociateModel[]>(environment.apiUrl + "/api/associate/getall");
  }

  deleteAssociate(associateFormObj: AssociateModel): Observable<any> {
    return this.http.post<any>(environment.apiUrl + "/api/associate/delete", associateFormObj);
  }

  updateAssociateSubmit(associateFormObj: AssociateModel): Observable<any> {
    return this.http.post<any>(environment.apiUrl + "/api/associate/edit", associateFormObj);
  }

  checkAssociateId(associateFormObj: AssociateModel): Observable<any> {
    return this.http.post<any>(environment.apiUrl + "/api/associate/checkid", associateFormObj);
  }

}
